import { getCollection, saveCollection } from './db';

export const cakeService = {
  getCategories: () => {
    const categories = getCollection('CATEGORIES').filter(c => c.enable === 1);
    const templates = getCollection('TEMPLATES').filter(t => t.Status === 'Active');
    // Chỉ giữ lại những danh mục thực sự có bánh
    return categories.filter(cat => templates.some(tpl => tpl.Category_ID === cat.Category_ID));
  },

  getTemplates: (categoryId = null) => {
    const templates = getCollection('TEMPLATES').filter(t => t.Status === 'Active');
    if (categoryId && categoryId !== 'ALL') {
      return templates.filter(t => t.Category_ID === categoryId);
    }
    return templates;
  },

  getAllTemplates: () => {
    return getCollection('TEMPLATES');
  },

  getTemplateById: (templateId) => {
    const templates = getCollection('TEMPLATES');
    return templates.find(t => t.Template_ID === templateId);
  },

  getAccessories: () => {
    return getCollection('ACCESSORIES').filter(a => a.Status === 'Active');
  },

  addTemplate: (cake) => {
    const templates = getCollection('TEMPLATES');
    const newId = 'TPL-' + String(templates.length + 1).padStart(3, '0');
    const newCake = {
      Template_ID: newId,
      Status: 'Active',
      Is_Featured: 0,
      Allows_Greeting: 1,
      ...cake
    };
    templates.push(newCake);
    saveCollection('TEMPLATES', templates);
    return newCake;
  },

  deleteTemplate: (templateId) => {
    const templates = getCollection('TEMPLATES');
    const updated = templates.filter(t => t.Template_ID !== templateId);
    saveCollection('TEMPLATES', updated);

    // Xóa luôn danh mục nếu sau khi xóa bánh không còn chiếc bánh nào trong danh mục đó
    const categories = getCollection('CATEGORIES');
    const activeCategories = categories.filter(cat => 
      updated.some(t => t.Category_ID === cat.Category_ID && t.Status === 'Active')
    );
    saveCollection('CATEGORIES', activeCategories);
  },

  // Simple and transparent price calculation for custom cakes
  calculateCustomCakePrice: (template, layersCount = 2, frostingType = 'Standard', topping = 'None') => {
    const basePrice = template ? Number(template.Price) : 250000;
    
    // Default cake comes with 2 layers; each extra layer costs 30,000 VND
    const extraLayers = Math.max(0, layersCount - 2);
    const extraLayersFee = extraLayers * 30000;

    // Special premium frostings cost 20,000 VND extra
    const frostingFee = frostingType === 'CreamCheese' || frostingType === 'ChocolateGanache' ? 20000 : 0;

    // Toppings cost 20,000 VND extra
    const toppingFee = topping && topping !== 'None' ? 20000 : 0;

    return basePrice + extraLayersFee + frostingFee + toppingFee;
  }
};
