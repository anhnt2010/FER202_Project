import usersDefault from '../data/users.json';
import customersDefault from '../data/customers.json';
import categoriesDefault from '../data/product_categories.json';
import templatesDefault from '../data/cake_templates.json';
import accessoriesDefault from '../data/accessories.json';
import ordersDefault from '../data/orders.json';
import reviewsDefault from '../data/reviews.json';

const KEYS = {
  USERS: 'bz_users',
  CUSTOMERS: 'bz_customers',
  CATEGORIES: 'bz_categories',
  TEMPLATES: 'bz_templates',
  ACCESSORIES: 'bz_accessories',
  ORDERS: 'bz_orders',
  REVIEWS: 'bz_reviews'
};

// Initialize DB with seed data and auto-clean unused data
export const initDB = () => {
  // 1. Auto clean unused accounts (remove R03, R04, nhanvien, shipper, khachhang2)
  const existingUsers = localStorage.getItem(KEYS.USERS);
  if (!existingUsers) {
    localStorage.setItem(KEYS.USERS, JSON.stringify(usersDefault));
  } else {
    try {
      const parsedUsers = JSON.parse(existingUsers);
      const cleanedUsers = parsedUsers.filter(u => 
        (u.Role_ID === 'R01' || u.Role_ID === 'R02') &&
        u.Email !== 'khachhang2@gmail.com' &&
        !u.Email.includes('nhanvien') &&
        !u.Email.includes('shipper')
      );
      if (cleanedUsers.length !== parsedUsers.length) {
        localStorage.setItem(KEYS.USERS, JSON.stringify(cleanedUsers));
      }
    } catch {
      localStorage.setItem(KEYS.USERS, JSON.stringify(usersDefault));
    }
  }

  // 2. Customers
  const existingCustomers = localStorage.getItem(KEYS.CUSTOMERS);
  if (!existingCustomers) {
    localStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(customersDefault));
  } else {
    try {
      const parsedCus = JSON.parse(existingCustomers);
      const cleanedCus = parsedCus.filter(c => c.Customer_ID !== 'CUS-002');
      if (cleanedCus.length !== parsedCus.length) {
        localStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(cleanedCus));
      }
    } catch {
      localStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(customersDefault));
    }
  }

  // 3. Templates (ensure simplified Price format)
  const existingTemplates = localStorage.getItem(KEYS.TEMPLATES);
  if (!existingTemplates || !JSON.parse(existingTemplates)[0]?.Price) {
    localStorage.setItem(KEYS.TEMPLATES, JSON.stringify(templatesDefault));
  }

  // 4. Categories (TỰ ĐỘNG XÓA CÁC DANH MỤC KHÔNG CÓ BÁNH)
  const currentTemplates = JSON.parse(localStorage.getItem(KEYS.TEMPLATES) || '[]');
  const existingCategories = localStorage.getItem(KEYS.CATEGORIES);
  let categoriesToClean = existingCategories ? JSON.parse(existingCategories) : categoriesDefault;

  // Filter out any category that has 0 active cakes
  const validCategories = categoriesToClean.filter(cat => 
    cat.enable === 1 && currentTemplates.some(t => t.Category_ID === cat.Category_ID && t.Status === 'Active')
  );

  localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(validCategories.length > 0 ? validCategories : categoriesDefault));

  // 5. Accessories
  if (!localStorage.getItem(KEYS.ACCESSORIES)) {
    localStorage.setItem(KEYS.ACCESSORIES, JSON.stringify(accessoriesDefault));
  }

  // 6. Orders
  const existingOrders = localStorage.getItem(KEYS.ORDERS);
  if (!existingOrders || !JSON.parse(existingOrders)[0]?.Total_Price) {
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(ordersDefault));
  }

  // 7. Reviews
  if (!localStorage.getItem(KEYS.REVIEWS)) {
    localStorage.setItem(KEYS.REVIEWS, JSON.stringify(reviewsDefault));
  }
};

export const getCollection = (keyName) => {
  initDB();
  const data = localStorage.getItem(KEYS[keyName]);
  return data ? JSON.parse(data) : [];
};

export const saveCollection = (keyName, data) => {
  localStorage.setItem(KEYS[keyName], JSON.stringify(data));
};

export { KEYS };
