import { getCollection, saveCollection } from './db';

export const reviewService = {
  getReviewsByProductId: (templateId) => {
    const reviews = getCollection('REVIEWS');
    return reviews.filter(r => r.Template_ID === templateId);
  },

  hasBoughtProduct: (customerId, templateId) => {
    if (!customerId) return false;
    const orders = getCollection('ORDERS');
    return orders.some(o => 
      o.Customer_ID === customerId &&
      o.Items.some(i => i.Template_ID === templateId)
    );
  },

  hasReviewed: (customerId, templateId) => {
    if (!customerId) return false;
    const reviews = getCollection('REVIEWS');
    return reviews.some(r => r.Customer_ID === customerId && r.Template_ID === templateId);
  },

  addReview: (customerId, customerName, templateId, ratingStars, comment) => {
    const reviews = getCollection('REVIEWS');
    const reviewId = 'REV-' + String(reviews.length + 1).padStart(3, '0');
    
    const newReview = {
      Review_ID: reviewId,
      Template_ID: templateId,
      Customer_ID: customerId,
      Customer_Name: customerName,
      Rating_Stars: Number(ratingStars),
      Comment: comment || '',
      Review_Date: new Date().toISOString()
    };

    reviews.push(newReview);
    saveCollection('REVIEWS', reviews);
    return newReview;
  }
};
