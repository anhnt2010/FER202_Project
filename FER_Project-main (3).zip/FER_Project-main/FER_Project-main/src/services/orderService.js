import { getCollection, saveCollection } from './db';

export const orderService = {
  createOrder: (customerId, customerName, phone, address, items, totalPrice) => {
    const orders = getCollection('ORDERS');
    const orderNo = 'ORD-' + String(orders.length + 1).padStart(3, '0');

    const newOrder = {
      Order_No: orderNo,
      Customer_ID: customerId,
      Customer_Name: customerName,
      Phone: phone,
      Delivery_Address: address,
      Order_Date: new Date().toISOString(),
      Total_Price: totalPrice,
      OrderStatus: 'Pending',
      Items: items.map(item => ({
        Template_ID: item.Template_ID || item.Accessory_ID,
        Template_Name: item.Template_Name,
        Price: item.Price,
        Quantity: item.Quantity,
        Greeting_Text: item.Greeting_Text || '',
        Flavour: item.Flavour || '',
        Frosting: item.Frosting || '',
        Image_URL: item.Image_URL || ''
      }))
    };

    orders.unshift(newOrder);
    saveCollection('ORDERS', orders);
    return newOrder;
  },

  getOrdersByCustomer: (customerId) => {
    const orders = getCollection('ORDERS');
    return orders.filter(o => o.Customer_ID === customerId);
  },

  getAllOrders: () => {
    return getCollection('ORDERS');
  },

  updateOrderStatus: (orderNo, status) => {
    const orders = getCollection('ORDERS');
    const idx = orders.findIndex(o => o.Order_No === orderNo);
    if (idx !== -1) {
      orders[idx].OrderStatus = status;
      saveCollection('ORDERS', orders);
      return orders[idx];
    }
    throw new Error('Không tìm thấy đơn hàng!');
  }
};
