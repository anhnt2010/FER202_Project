import React from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export const AdminLayout = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/auth/login');
  };

  const navItems = [
    { path: '/admin', label: '📊 Tổng quan & Đơn hàng' },
    { path: '/admin/templates', label: '🍰 Quản lý mẫu bánh' },
    { path: '/admin/users', label: '👥 Quản lý tài khoản' }
  ];

  return (
    <div style={{ display: 'flex', minHeight: '100vh', fontFamily: 'Inter, sans-serif', backgroundColor: '#f5f5f5' }}>
      {/* Sidebar */}
      <aside style={{ width: '250px', backgroundColor: '#1a1a24', color: '#a0a0b0', display: 'flex', flexDirection: 'column', borderRight: '1px solid #2e2e3e' }}>
        <div style={{ padding: '1.5rem', borderBottom: '1px solid #2e2e3e' }}>
          <Link to="/admin" style={{ textDecoration: 'none' }}>
            <span style={{ fontSize: '1.3rem', fontWeight: 800, color: '#ffffff' }}>🎂 Bakery Admin</span>
          </Link>
          <div style={{ fontSize: '0.75rem', color: '#ff8f00', marginTop: '0.25rem', fontWeight: 'bold' }}>QUẢN TRỊ VIÊN</div>
        </div>

        <nav style={{ flex: 1, padding: '1rem' }}>
          {navItems.map(item => {
            const isActive = location.pathname === item.path;
            return (
              <Link 
                key={item.path} 
                to={item.path} 
                style={{ 
                  display: 'block', padding: '0.8rem 1rem', textDecoration: 'none', 
                  borderRadius: '6px', marginBottom: '0.5rem', fontWeight: 600,
                  backgroundColor: isActive ? '#d84315' : 'transparent',
                  color: isActive ? '#ffffff' : '#a0a0b0',
                  transition: 'all 0.2s'
                }}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div style={{ padding: '1.5rem', borderTop: '1px solid #2e2e3e' }}>
          <button 
            onClick={handleLogout}
            style={{ 
              width: '100%', padding: '0.6rem', border: '1px solid #ff3333', borderRadius: '6px',
              backgroundColor: 'transparent', color: '#ff3333', fontWeight: 'bold', cursor: 'pointer'
            }}
          >
            Đăng xuất
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <header style={{ height: '60px', backgroundColor: '#ffffff', borderBottom: '1px solid #e0e0e0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 2rem' }}>
          <Link to="/" style={{ textDecoration: 'none', color: '#d84315', fontWeight: 600, fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <span>🛍️</span> Xem trang bán hàng
          </Link>
          <div style={{ fontWeight: 'bold', color: '#333333' }}>
            👤 {user?.details?.Full_Name || 'Quản trị viên'}
          </div>
        </header>
        
        <main style={{ flex: 1, padding: '2rem', overflowY: 'auto' }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
