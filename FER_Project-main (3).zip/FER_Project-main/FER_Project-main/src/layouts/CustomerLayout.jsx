import React from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

export const CustomerLayout = () => {
  const { user, logout } = useAuth();
  const { cartItems } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/auth/login');
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.Quantity, 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', fontFamily: 'Inter, sans-serif', backgroundColor: '#faf6f0', color: '#3e2723' }}>
      {/* Header */}
      <header style={{ 
        position: 'sticky', top: 0, zIndex: 100,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center', 
        padding: '1rem 2rem', backgroundColor: '#ffffff', boxShadow: '0 2px 10px rgba(62, 39, 35, 0.05)',
        borderBottom: '1px solid #efebe9', flexWrap: 'wrap', gap: '1rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
          <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ fontSize: '1.5rem', fontWeight: 800, background: 'linear-gradient(135deg, #d84315 0%, #ff8f00 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              🎂 BakeryZone
            </span>
          </Link>
          <nav style={{ display: 'flex', gap: '1.25rem' }}>
            <Link to="/" style={{ textDecoration: 'none', color: '#5d4037', fontWeight: 600 }}>Trang chủ</Link>
            <Link to="/products" style={{ textDecoration: 'none', color: '#5d4037', fontWeight: 600 }}>Mẫu bánh</Link>
            {user?.Role_ID !== 'R01' && (
              <Link to="/custom-cake" style={{ textDecoration: 'none', color: '#5d4037', fontWeight: 600 }}>Thiết kế bánh</Link>
            )}
            <Link to="/orders" style={{ textDecoration: 'none', color: '#5d4037', fontWeight: 600 }}>Lịch sử đơn</Link>
          </nav>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
          <Link to="/cart" style={{ textDecoration: 'none', position: 'relative', display: 'flex', alignItems: 'center' }}>
            <span style={{ fontSize: '1.4rem' }}>🛒</span>
            {totalCartCount > 0 && (
              <span style={{ 
                position: 'absolute', top: '-8px', right: '-8px', 
                backgroundColor: '#d84315', color: '#ffffff', 
                fontSize: '0.75rem', fontWeight: 'bold', borderRadius: '50%', 
                padding: '2px 6px', display: 'inline-block'
              }}>
                {totalCartCount}
              </span>
            )}
          </Link>

          {user ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
              {user.Role_ID === 'R01' && (
                <Link to="/admin" style={{ textDecoration: 'none', padding: '0.35rem 0.75rem', backgroundColor: '#1a1a24', color: '#ffb74d', borderRadius: '6px', fontSize: '0.8rem', fontWeight: 'bold' }}>
                  ⚙️ Quản trị Admin
                </Link>
              )}
              <span style={{ fontWeight: 600, color: '#3e2723', fontSize: '0.9rem' }}>
                Hi, {user.details?.Full_Name || user.Email}
              </span>
              <button 
                onClick={handleLogout}
                style={{ 
                  padding: '0.35rem 0.8rem', border: '1px solid #d84315', borderRadius: '6px',
                  backgroundColor: 'transparent', color: '#d84315', fontWeight: 600, cursor: 'pointer',
                  fontSize: '0.85rem'
                }}
              >
                Đăng xuất
              </button>
            </div>
          ) : (
            <Link 
              to="/auth/login" 
              style={{ 
                textDecoration: 'none', padding: '0.5rem 1.2rem', backgroundColor: '#d84315', 
                color: '#ffffff', borderRadius: '8px', fontWeight: 600 
              }}
            >
              Đăng nhập
            </Link>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main style={{ flex: 1, padding: '2rem' }}>
        <Outlet />
      </main>

      {/* Footer */}
      <footer style={{ backgroundColor: '#3e2723', color: '#efebe9', padding: '2rem', textAlign: 'center', borderTop: '1px solid #3e2723' }}>
        <p style={{ margin: 0, fontWeight: 500 }}>&copy; 2026 BakeryZone - Cửa hàng bánh kem sinh nhật & thiết kế bánh trực tuyến.</p>
        <p style={{ margin: '0.5rem 0 0 0', fontSize: '0.85rem', color: '#b0bec5' }}>Đồ án môn FER202 - Front-End Web Development with React</p>
      </footer>
    </div>
  );
};

export default CustomerLayout;
