import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    const savedCart = localStorage.getItem('bz_cart');
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    }
  }, []);

  const saveCart = (items) => {
    setCartItems(items);
    localStorage.setItem('bz_cart', JSON.stringify(items));
  };

  const addToCart = (item) => {
    const existingIndex = cartItems.findIndex(i => 
      i.Template_ID === item.Template_ID &&
      i.Greeting_Text === item.Greeting_Text &&
      i.Flavour === item.Flavour &&
      i.Frosting === item.Frosting
    );

    if (existingIndex !== -1) {
      const updated = [...cartItems];
      updated[existingIndex].Quantity += (item.Quantity || 1);
      saveCart(updated);
    } else {
      const newItem = {
        ...item,
        Quantity: item.Quantity || 1,
        id: 'CART-' + Date.now() + '-' + Math.floor(Math.random() * 1000)
      };
      saveCart([...cartItems, newItem]);
    }
  };

  const removeFromCart = (id) => {
    const updated = cartItems.filter(i => i.id !== id);
    saveCart(updated);
  };

  const updateQuantity = (id, quantity) => {
    if (quantity <= 0) {
      removeFromCart(id);
      return;
    }
    const updated = cartItems.map(i => i.id === id ? { ...i, Quantity: quantity } : i);
    saveCart(updated);
  };

  const clearCart = () => {
    saveCart([]);
  };

  const getCartTotal = () => {
    return cartItems.reduce((sum, item) => sum + (Number(item.Price) * item.Quantity), 0);
  };

  return (
    <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, updateQuantity, clearCart, getCartTotal }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
export default CartContext;
