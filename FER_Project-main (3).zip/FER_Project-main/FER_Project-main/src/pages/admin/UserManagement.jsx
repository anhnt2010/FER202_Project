import React, { useState, useEffect } from 'react';
import { getCollection, saveCollection } from '../../services/db';

export const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const roles = {
    'R01': 'Quản trị viên (Admin)',
    'R02': 'Khách hàng (Customer)'
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = () => {
    const allUsers = getCollection('USERS');
    // Loại bỏ tài khoản không dùng (R03, R04, khachhang2, nhanvien, shipper)
    const activeUsers = allUsers.filter(u => 
      (u.Role_ID === 'R01' || u.Role_ID === 'R02') &&
      u.Email !== 'khachhang2@gmail.com' &&
      !u.Email.includes('nhanvien') &&
      !u.Email.includes('shipper')
    );
    if (activeUsers.length !== allUsers.length) {
      saveCollection('USERS', activeUsers);
    }
    setUsers(activeUsers);
  };

  const toggleUserStatus = (userId) => {
    const allUsers = getCollection('USERS');
    const idx = allUsers.findIndex(u => u.User_ID === userId);
    if (idx !== -1) {
      if (allUsers[idx].Role_ID === 'R01') {
        alert('Không thể khóa tài khoản Quản trị tối cao!');
        return;
      }
      allUsers[idx].Account_Status = allUsers[idx].Account_Status === 'Active' ? 'Suspended' : 'Active';
      saveCollection('USERS', allUsers);
      loadUsers();
    }
  };

  const deleteUser = (userId) => {
    if (userId === 'U001') {
      alert('Không thể xóa tài khoản Quản trị tối cao!');
      return;
    }
    if (window.confirm(`Bạn có chắc chắn muốn xóa tài khoản ${userId}?`)) {
      const allUsers = getCollection('USERS');
      const updated = allUsers.filter(u => u.User_ID !== userId);
      saveCollection('USERS', updated);
      loadUsers();
      alert(`Đã xóa tài khoản ${userId} thành công!`);
    }
  };

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString('vi-VN');
  };

  return (
    <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 15px rgba(0,0,0,0.02)', border: '1px solid #efebe9', fontFamily: 'Inter, sans-serif' }}>
      <h2 style={{ fontSize: '1.25rem', marginBottom: '1.25rem', color: '#333' }}>
        👥 Quản lý tài khoản người dùng ({users.length})
      </h2>

      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.9rem' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #eee', color: '#666' }}>
              <th style={{ padding: '0.75rem' }}>Mã người dùng</th>
              <th style={{ padding: '0.75rem' }}>Email đăng nhập</th>
              <th style={{ padding: '0.75rem' }}>Vai trò</th>
              <th style={{ padding: '0.75rem' }}>Ngày tạo</th>
              <th style={{ padding: '0.75rem' }}>Trạng thái</th>
              <th style={{ padding: '0.75rem' }}>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.User_ID} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '0.75rem', fontWeight: 'bold' }}>{u.User_ID}</td>
                <td style={{ padding: '0.75rem' }}>{u.Email}</td>
                <td style={{ padding: '0.75rem' }}>
                  <span style={{ 
                    backgroundColor: u.Role_ID === 'R01' ? '#fff3e0' : '#e8f5e9',
                    color: u.Role_ID === 'R01' ? '#ef6c00' : '#2e7d32',
                    padding: '3px 8px', borderRadius: '4px', fontWeight: 'bold', fontSize: '0.8rem'
                  }}>
                    {roles[u.Role_ID] || u.Role_ID}
                  </span>
                </td>
                <td style={{ padding: '0.75rem' }}>{formatDate(u.Created_At)}</td>
                <td style={{ padding: '0.75rem' }}>
                  <span style={{ 
                    backgroundColor: u.Account_Status === 'Active' ? '#e8f5e9' : '#ffebee',
                    color: u.Account_Status === 'Active' ? '#2e7d32' : '#c62828',
                    padding: '2px 8px', borderRadius: '4px', fontSize: '0.8rem', fontWeight: 'bold'
                  }}>
                    {u.Account_Status === 'Active' ? 'Hoạt động' : 'Đã khóa'}
                  </span>
                </td>
                <td style={{ padding: '0.75rem' }}>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button 
                      onClick={() => toggleUserStatus(u.User_ID)}
                      disabled={u.Role_ID === 'R01'}
                      style={{ 
                        padding: '0.25rem 0.5rem', border: 'none', borderRadius: '4px', cursor: u.Role_ID === 'R01' ? 'not-allowed' : 'pointer',
                        backgroundColor: u.Account_Status === 'Active' ? '#fff3e0' : '#e8f5e9',
                        color: u.Account_Status === 'Active' ? '#ef6c00' : '#2e7d32',
                        fontWeight: 'bold', fontSize: '0.8rem'
                      }}
                    >
                      {u.Account_Status === 'Active' ? 'Khóa' : 'Mở khóa'}
                    </button>

                    {u.Role_ID !== 'R01' && (
                      <button 
                        onClick={() => deleteUser(u.User_ID)}
                        style={{ 
                          padding: '0.25rem 0.5rem', border: 'none', borderRadius: '4px', cursor: 'pointer',
                          backgroundColor: '#ffebee',
                          color: '#c62828',
                          fontWeight: 'bold', fontSize: '0.8rem'
                        }}
                      >
                        Xóa
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UserManagement;
