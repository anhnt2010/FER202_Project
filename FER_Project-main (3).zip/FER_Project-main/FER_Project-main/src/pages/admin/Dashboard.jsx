import React, { useState, useEffect } from 'react';
import { orderService } from '../../services/orderService';

export const Dashboard = () => {
  const [orders, setOrders] = useState([]);
  const [stats, setStats] = useState({ revenue: 0, total: 0, pending: 0 });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const allOrders = orderService.getAllOrders();
    setOrders(allOrders);

    // Calculate stats
    const revenue = allOrders.reduce((sum, o) => o.OrderStatus === 'Completed' ? sum + Number(o.Total_Price) : sum, 0);
    const pending = allOrders.filter(o => o.OrderStatus === 'Pending' || o.OrderStatus === 'Processing').length;

    setStats({
      revenue,
      total: allOrders.length,
      pending
    });
  };

  const handleStatusChange = (orderNo, newStatus) => {
    try {
      orderService.updateOrderStatus(orderNo, newStatus);
      loadData();
      alert(`Đã cập nhật đơn hàng ${orderNo} sang trạng thái: ${newStatus}`);
    } catch (err) {
      alert(err.message);
    }
  };

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleString('vi-VN', {
      month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', fontFamily: 'Inter, sans-serif' }}>
      <h1 style={{ margin: 0, color: '#333' }}>📊 Quản lý đơn hàng & Thống kê</h1>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.5rem' }}>
        <div style={kpiCardStyle}>
          <div style={{ fontSize: '2.5rem' }}>💰</div>
          <div>
            <div style={{ color: '#888', fontSize: '0.9rem' }}>Tổng doanh thu (Hoàn thành)</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#2e7d32' }}>
              {stats.revenue.toLocaleString('vi-VN')} VND
            </div>
          </div>
        </div>

        <div style={kpiCardStyle}>
          <div style={{ fontSize: '2.5rem' }}>📦</div>
          <div>
            <div style={{ color: '#888', fontSize: '0.9rem' }}>Tổng số đơn hàng</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{stats.total} đơn</div>
          </div>
        </div>

        <div style={kpiCardStyle}>
          <div style={{ fontSize: '2.5rem' }}>⏳</div>
          <div>
            <div style={{ color: '#888', fontSize: '0.9rem' }}>Đơn hàng đang xử lý</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#d84315' }}>{stats.pending} đơn</div>
          </div>
        </div>
      </div>

      {/* Orders List */}
      <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 15px rgba(0,0,0,0.03)' }}>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '1.25rem', color: '#333' }}>📋 Danh sách đơn đặt bánh</h2>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', minWidth: '750px' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #eee', color: '#666', fontSize: '0.9rem' }}>
                <th style={{ padding: '0.75rem' }}>Mã đơn</th>
                <th style={{ padding: '0.75rem' }}>Khách hàng</th>
                <th style={{ padding: '0.75rem' }}>Số điện thoại</th>
                <th style={{ padding: '0.75rem' }}>Địa chỉ nhận hàng</th>
                <th style={{ padding: '0.75rem' }}>Thời gian đặt</th>
                <th style={{ padding: '0.75rem' }}>Tổng tiền</th>
                <th style={{ padding: '0.75rem' }}>Trạng thái đơn</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr key={order.Order_No} style={{ borderBottom: '1px solid #eee', fontSize: '0.9rem' }}>
                  <td style={{ padding: '1rem 0.75rem', fontWeight: 'bold' }}>{order.Order_No}</td>
                  <td style={{ padding: '1rem 0.75rem' }}>{order.Customer_Name || order.Customer_ID}</td>
                  <td style={{ padding: '1rem 0.75rem' }}>{order.Phone || '---'}</td>
                  <td style={{ padding: '1rem 0.75rem', maxWidth: '220px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {order.Delivery_Address}
                  </td>
                  <td style={{ padding: '1rem 0.75rem' }}>{formatDate(order.Order_Date)}</td>
                  <td style={{ padding: '1rem 0.75rem', fontWeight: 'bold', color: '#d84315' }}>
                    {Number(order.Total_Price).toLocaleString('vi-VN')} VND
                  </td>
                  <td style={{ padding: '1rem 0.75rem' }}>
                    <select 
                      value={order.OrderStatus}
                      onChange={e => handleStatusChange(order.Order_No, e.target.value)}
                      style={{ 
                        padding: '0.35rem 0.6rem', 
                        borderRadius: '6px', 
                        border: '1px solid #ccc',
                        fontWeight: 'bold',
                        cursor: 'pointer',
                        backgroundColor: order.OrderStatus === 'Completed' ? '#e8f5e9' : order.OrderStatus === 'Processing' ? '#e3f2fd' : '#fff'
                      }}
                    >
                      <option value="Pending">Pending (Chờ xác nhận)</option>
                      <option value="Processing">Processing (Đang làm)</option>
                      <option value="Completed">Completed (Hoàn thành)</option>
                      <option value="Canceled">Canceled (Đã hủy)</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const kpiCardStyle = {
  backgroundColor: '#ffffff',
  borderRadius: '12px',
  padding: '1.5rem',
  boxShadow: '0 4px 15px rgba(0,0,0,0.02)',
  display: 'flex',
  alignItems: 'center',
  gap: '1.5rem',
  border: '1px solid #efebe9'
};

export default Dashboard;
