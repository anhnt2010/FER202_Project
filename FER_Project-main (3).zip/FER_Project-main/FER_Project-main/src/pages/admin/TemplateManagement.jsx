import React, { useState, useEffect } from 'react';
import { cakeService } from '../../services/cakeService';

export const TemplateManagement = () => {
  const [templates, setTemplates] = useState([]);
  const [categories, setCategories] = useState([]);

  // Form State
  const [name, setName] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [price, setPrice] = useState(250000);
  const [imageUrl, setImageUrl] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    loadTemplates();
    setCategories(cakeService.getCategories());
  }, []);

  const loadTemplates = () => {
    setTemplates(cakeService.getAllTemplates());
  };

  const handleAddTemplate = (e) => {
    e.preventDefault();
    if (!name || !categoryId) {
      alert('Vui lòng điền tên mẫu bánh và chọn danh mục!');
      return;
    }

    cakeService.addTemplate({
      Category_ID: categoryId,
      Template_Name: name,
      Price: Number(price),
      Image_URL: imageUrl || 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800',
      Full_Description: description || 'Mẫu bánh kem thơm ngon hảo hạng cho bữa tiệc của bạn.'
    });

    loadTemplates();

    // Reset Form
    setName('');
    setImageUrl('');
    setDescription('');
    setPrice(250000);
    alert('Thêm mẫu bánh mới thành công!');
  };

  const handleDeleteTemplate = (id) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa mẫu bánh ${id}?`)) {
      cakeService.deleteTemplate(id);
      loadTemplates();
    }
  };

  const getCategoryName = (catId) => {
    const cat = categories.find(c => c.Category_ID === catId);
    return cat ? cat.Category_Name : catId;
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '2rem', fontFamily: 'Inter, sans-serif', alignItems: 'start' }}>
      
      {/* Templates List */}
      <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 15px rgba(0,0,0,0.02)', border: '1px solid #efebe9' }}>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '1.25rem', color: '#333' }}>🍰 Danh sách mẫu bánh kem ({templates.length})</h2>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.9rem' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #eee', color: '#666' }}>
                <th style={{ padding: '0.75rem' }}>Ảnh</th>
                <th style={{ padding: '0.75rem' }}>Tên mẫu</th>
                <th style={{ padding: '0.75rem' }}>Danh mục</th>
                <th style={{ padding: '0.75rem' }}>Giá bán</th>
                <th style={{ padding: '0.75rem' }}>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {templates.map(t => (
                <tr key={t.Template_ID} style={{ borderBottom: '1px solid #eee' }}>
                  <td style={{ padding: '0.5rem' }}>
                    <img 
                      src={t.Image_URL} 
                      alt="" 
                      style={{ width: '45px', height: '45px', objectFit: 'cover', borderRadius: '6px' }} 
                    />
                  </td>
                  <td style={{ padding: '0.75rem', fontWeight: 'bold' }}>{t.Template_Name}</td>
                  <td style={{ padding: '0.75rem' }}>{getCategoryName(t.Category_ID)}</td>
                  <td style={{ padding: '0.75rem', fontWeight: 'bold', color: '#d84315' }}>
                    {Number(t.Price || 250000).toLocaleString('vi-VN')} VND
                  </td>
                  <td style={{ padding: '0.75rem' }}>
                    <button 
                      onClick={() => handleDeleteTemplate(t.Template_ID)}
                      style={{ padding: '0.3rem 0.6rem', backgroundColor: '#ffebee', color: '#c62828', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}
                    >
                      Xóa
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Form */}
      <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 15px rgba(0,0,0,0.02)', border: '1px solid #efebe9', height: 'fit-content' }}>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '1.25rem', color: '#333' }}>➕ Thêm mẫu bánh mới</h2>
        
        <form onSubmit={handleAddTemplate} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <label style={labelStyle}>Tên mẫu bánh</label>
            <input type="text" required value={name} onChange={e => setName(e.target.value)} style={inputStyle} placeholder="Bánh kem Matcha Đậu Đỏ" />
          </div>

          <div>
            <label style={labelStyle}>Danh mục phân loại</label>
            <select value={categoryId} onChange={e => setCategoryId(e.target.value)} required style={selectStyle}>
              <option value="">-- Chọn danh mục --</option>
              {categories.map(c => (
                <option key={c.Category_ID} value={c.Category_ID}>{c.Category_Name}</option>
              ))}
            </select>
          </div>

          <div>
            <label style={labelStyle}>Giá bán (VND)</label>
            <input type="number" step="10000" min="50000" required value={price} onChange={e => setPrice(e.target.value)} style={inputStyle} />
          </div>

          <div>
            <label style={labelStyle}>Ảnh mẫu bánh (Link URL)</label>
            <input type="text" value={imageUrl} onChange={e => setImageUrl(e.target.value)} style={inputStyle} placeholder="https://images.unsplash.com/..." />
          </div>

          <div>
            <label style={labelStyle}>Mô tả bánh</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} style={{ ...inputStyle, height: '70px', resize: 'vertical' }} placeholder="Mô tả hương vị, nguyên liệu nổi bật..." />
          </div>

          <button type="submit" style={{ 
            padding: '0.75rem', backgroundColor: '#d84315', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer',
            boxShadow: '0 4px 10px rgba(216, 67, 21, 0.2)'
          }}>
            Lưu mẫu bánh
          </button>
        </form>
      </div>

    </div>
  );
};

const labelStyle = {
  display: 'block',
  marginBottom: '0.4rem',
  fontSize: '0.85rem',
  fontWeight: 'bold',
  color: '#5d4037'
};

const inputStyle = {
  width: '100%',
  padding: '0.6rem 0.8rem',
  border: '1px solid #d7ccc8',
  borderRadius: '8px',
  fontSize: '0.9rem',
  outline: 'none',
  boxSizing: 'border-box'
};

const selectStyle = {
  width: '100%',
  padding: '0.6rem 0.8rem',
  border: '1px solid #d7ccc8',
  borderRadius: '8px',
  backgroundColor: '#ffffff',
  fontSize: '0.9rem',
  outline: 'none'
};

export default TemplateManagement;
