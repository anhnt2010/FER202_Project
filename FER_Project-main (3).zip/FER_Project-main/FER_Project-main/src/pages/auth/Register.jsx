import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export const Register = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    try {
      register(email, password, fullName, phone, address);
      setSuccess(true);
      setTimeout(() => {
        navigate('/auth/login');
      }, 2000);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={{ 
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', 
      background: 'linear-gradient(135deg, #efebe9 0%, #d7ccc8 100%)', fontFamily: 'Inter, sans-serif', padding: '2rem'
    }}>
      <div style={{ backgroundColor: '#ffffff', borderRadius: '16px', padding: '2.5rem', boxShadow: '0 8px 30px rgba(62, 39, 35, 0.08)', maxWidth: '500px', width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <h2 style={{ margin: 0, fontSize: '1.8rem', fontWeight: 800, color: '#3e2723' }}>Đăng ký tài khoản</h2>
          <p style={{ margin: '0.5rem 0 0 0', color: '#795548', fontSize: '0.95rem' }}>Trở thành thành viên của BakeryZone</p>
        </div>

        {error && (
          <div style={{ 
            backgroundColor: '#ffebee', color: '#c62828', padding: '0.75rem 1rem', 
            borderRadius: '8px', marginBottom: '1.5rem', fontSize: '0.9rem', fontWeight: 600 
          }}>
            ⚠️ {error}
          </div>
        )}

        {success && (
          <div style={{ 
            backgroundColor: '#e8f5e9', color: '#2e7d32', padding: '0.75rem 1rem', 
            borderRadius: '8px', marginBottom: '1.5rem', fontSize: '0.9rem', fontWeight: 600 
          }}>
            🎉 Đăng ký thành công! Đang chuyển sang trang Đăng nhập...
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.2rem' }}>
          <div>
            <label style={labelStyle}>Họ và Tên</label>
            <input type="text" required placeholder="Nguyễn Văn A" value={fullName} onChange={e => setFullName(e.target.value)} style={inputStyle} />
          </div>

          <div>
            <label style={labelStyle}>Số điện thoại</label>
            <input type="text" required placeholder="0912345678" value={phone} onChange={e => setPhone(e.target.value)} style={inputStyle} />
          </div>

          <div>
            <label style={labelStyle}>Địa chỉ nhận hàng mặc định</label>
            <input type="text" required placeholder="Số 123 Đường Lê Lợi, Q.1, TP. HCM" value={address} onChange={e => setAddress(e.target.value)} style={inputStyle} />
          </div>

          <div>
            <label style={labelStyle}>Email</label>
            <input type="email" required placeholder="ten@example.com" value={email} onChange={e => setEmail(e.target.value)} style={inputStyle} />
          </div>

          <div>
            <label style={labelStyle}>Mật khẩu</label>
            <input type="password" required placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} style={inputStyle} />
          </div>

          <button type="submit" style={{ 
            backgroundColor: '#d84315', color: '#ffffff', border: 'none', borderRadius: '8px', 
            padding: '0.8rem', fontSize: '1rem', fontWeight: 'bold', cursor: 'pointer',
            marginTop: '0.5rem', boxShadow: '0 4px 12px rgba(216, 67, 21, 0.2)'
          }}>
            Tạo tài khoản
          </button>
        </form>

        <div style={{ marginTop: '1.5rem', textAlign: 'center', fontSize: '0.9rem', color: '#795548' }}>
          Đã có tài khoản? <Link to="/auth/login" style={{ color: '#d84315', fontWeight: 'bold', textDecoration: 'none' }}>Đăng nhập</Link>
        </div>
      </div>
    </div>
  );
};

const labelStyle = {
  display: 'block',
  marginBottom: '0.4rem',
  fontSize: '0.85rem',
  fontWeight: 600,
  color: '#5d4037'
};

const inputStyle = {
  width: '100%',
  padding: '0.7rem 1rem',
  border: '1px solid #d7ccc8',
  borderRadius: '8px',
  fontSize: '0.95rem',
  color: '#3e2723',
  outline: 'none',
  boxSizing: 'border-box'
};

export default Register;
