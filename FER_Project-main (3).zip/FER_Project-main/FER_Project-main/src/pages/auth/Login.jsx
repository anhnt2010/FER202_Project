import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import '../../assets/css/auth.css';

export const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    const cleanEmail = email ? email.trim().toLowerCase() : '';
    const cleanPassword = password || '';

    if (!cleanEmail || !cleanPassword) {
      setError('Vui lòng nhập đầy đủ email và mật khẩu.');
      return;
    }

    try {
      const user = login(cleanEmail, cleanPassword);
      if (user.Role_ID === 'R01') {
        navigate('/admin');
      } else {
        navigate('/');
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const autofill = (roleEmail) => {
    setEmail(roleEmail);
    setPassword('123');
    setError('');
  };

  return (
    <main className="auth-main">
      <section className="auth-section">
        <div className="auth-card login-card">
          
          {/* Left Visual Panel */}
          <div className="auth-visual">
            <div className="auth-badge">
              <span className="material-symbols-outlined">bakery_dining</span>
              BakeryZone
            </div>

            <div>
              <h1>Chào mừng bạn quay lại</h1>
              <p>
                Đăng nhập để đặt bánh kem thơm ngon, tự thiết kế bánh sinh nhật và theo dõi các đơn hàng của bạn.
              </p>
            </div>

            <div className="auth-benefits">
              <div>
                <span className="material-symbols-outlined">cake</span>
                Mẫu bánh kem đa dạng, cập nhật liên tục
              </div>
              <div>
                <span className="material-symbols-outlined">palette</span>
                Tự tay phối lớp, chọn kem theo sở thích
              </div>
              <div>
                <span className="material-symbols-outlined">local_shipping</span>
                Giao hàng đúng hẹn, chu đáo tận nơi
              </div>
            </div>
          </div>

          {/* Right Form Panel */}
          <div className="auth-form-wrap">
            <div className="auth-form-header">
              <span className="auth-label">Đăng nhập</span>
              <h2>Vào tài khoản</h2>
            </div>

            {error && (
              <div className="auth-message auth-error">
                <span className="material-symbols-outlined">error</span>
                <span>{error}</span>
              </div>
            )}

            <form className="auth-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <div className="input-wrap">
                  <span className="material-symbols-outlined input-icon">mail</span>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="admin@bakeryzone.com hoặc khachhang1@gmail.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="password">Mật khẩu</label>
                <div className="input-wrap">
                  <span className="material-symbols-outlined input-icon">lock</span>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="password"
                    name="password"
                    placeholder="Nhập mật khẩu (123)"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                  />
                  <span
                    className="material-symbols-outlined toggle-password"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{ cursor: 'pointer' }}
                  >
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </span>
                </div>
              </div>

              <button type="submit" className="btn btn-primary auth-submit">
                Đăng nhập
              </button>

              <p className="auth-switch">
                Chưa có tài khoản?{' '}
                <Link to="/auth/register">
                  Đăng ký ngay
                </Link>
              </p>
            </form>

            {/* Test Accounts Fast Login Card */}
            <div className="test-accounts-panel">
              <div className="test-accounts-title">🔑 Đăng nhập nhanh thử nghiệm (Mật khẩu: 123)</div>
              <div className="test-accounts-grid">
                <button type="button" className="test-btn" onClick={() => autofill('admin@bakeryzone.com')}>
                  🛡️ Quản trị viên (Admin)
                </button>
                <button type="button" className="test-btn" onClick={() => autofill('khachhang1@gmail.com')}>
                  🛍️ Khách hàng (Customer)
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>
    </main>
  );
};

export default Login;
