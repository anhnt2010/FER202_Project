import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { cakeService } from '../../services/cakeService';
import { useAuth } from '../../context/AuthContext';

export const ProductList = () => {
  const [categories, setCategories] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [filteredTemplates, setFilteredTemplates] = useState([]);
  const { user } = useAuth();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [sortBy, setSortBy] = useState('newest');

  const navigate = useNavigate();

  useEffect(() => {
    document.title = 'Mẫu Bánh Kem - BakeryZone';
    const cats = cakeService.getCategories();
    const tpls = cakeService.getTemplates();
    setCategories(cats);
    setTemplates(tpls);
    setFilteredTemplates(tpls);
  }, []);

  // Filter and sort
  useEffect(() => {
    let result = [...templates];

    if (selectedCategory !== 'ALL') {
      result = result.filter(t => t.Category_ID === selectedCategory);
    }

    if (searchTerm.trim() !== '') {
      result = result.filter(t => 
        t.Template_Name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (t.Full_Description && t.Full_Description.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (sortBy === 'priceAsc') {
      result.sort((a, b) => (a.Price || 0) - (b.Price || 0));
    } else if (sortBy === 'priceDesc') {
      result.sort((a, b) => (b.Price || 0) - (a.Price || 0));
    }

    setFilteredTemplates(result);
  }, [searchTerm, selectedCategory, sortBy, templates]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
      
      {/* Search and Sort Toolbar */}
      <section style={{ 
        backgroundColor: '#ffffff', 
        borderRadius: '16px', 
        padding: '1.25rem 1.5rem', 
        boxShadow: '0 4px 20px rgba(62, 39, 35, 0.04)',
        display: 'flex',
        flexWrap: 'wrap',
        gap: '1rem',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        {/* Search Input */}
        <div style={{ flex: '1 1 280px', position: 'relative' }}>
          <input
            type="text"
            placeholder="Tìm kiếm mẫu bánh..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              width: '100%',
              padding: '0.75rem 1rem 0.75rem 2.5rem',
              borderRadius: '8px',
              border: '1px solid #efebe9',
              fontSize: '0.95rem',
              backgroundColor: '#faf6f0',
              outline: 'none',
              boxSizing: 'border-box'
            }}
          />
          <span style={{ position: 'absolute', left: '0.8rem', top: '50%', transform: 'translateY(-50%)', opacity: 0.6 }}>🔍</span>
        </div>

        {/* Sort Select */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <span style={{ fontSize: '0.9rem', fontWeight: 600, color: '#5d4037' }}>Sắp xếp:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            style={{
              padding: '0.6rem 1rem',
              borderRadius: '8px',
              border: '1px solid #efebe9',
              backgroundColor: '#ffffff',
              fontSize: '0.9rem',
              outline: 'none',
              cursor: 'pointer'
            }}
          >
            <option value="newest">Mới nhất</option>
            <option value="priceAsc">Giá tăng dần</option>
            <option value="priceDesc">Giá giảm dần</option>
          </select>
        </div>
      </section>

      {/* Main Grid: Categories on Left, Products on Right */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '2rem', alignItems: 'start' }}>
        
        {/* Categories List */}
        <aside style={{ 
          backgroundColor: '#ffffff', 
          borderRadius: '16px', 
          padding: '1.25rem', 
          boxShadow: '0 4px 20px rgba(62, 39, 35, 0.04)',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.75rem'
        }}>
          <h3 style={{ margin: '0 0 0.5rem 0', fontSize: '1.1rem', color: '#3e2723', borderBottom: '2px solid #f5f5f5', paddingBottom: '0.5rem' }}>
            Danh mục bánh kem
          </h3>
          
          <button
            onClick={() => setSelectedCategory('ALL')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem',
              padding: '0.75rem 1rem',
              border: 'none',
              borderRadius: '8px',
              backgroundColor: selectedCategory === 'ALL' ? '#fdf8f5' : 'transparent',
              color: selectedCategory === 'ALL' ? '#d84315' : '#5d4037',
              fontWeight: selectedCategory === 'ALL' ? 'bold' : 'normal',
              textAlign: 'left',
              cursor: 'pointer',
              borderLeft: selectedCategory === 'ALL' ? '4px solid #d84315' : '4px solid transparent'
            }}
          >
            <span style={{ fontSize: '1.2rem' }}>🎂</span>
            <span>Tất cả mẫu bánh</span>
          </button>

          {categories.map(cat => (
            <button
              key={cat.Category_ID}
              onClick={() => setSelectedCategory(cat.Category_ID)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                padding: '0.75rem 1rem',
                border: 'none',
                borderRadius: '8px',
                backgroundColor: selectedCategory === cat.Category_ID ? '#fdf8f5' : 'transparent',
                color: selectedCategory === cat.Category_ID ? '#d84315' : '#5d4037',
                fontWeight: selectedCategory === cat.Category_ID ? 'bold' : 'normal',
                textAlign: 'left',
                cursor: 'pointer',
                borderLeft: selectedCategory === cat.Category_ID ? '4px solid #d84315' : '4px solid transparent'
              }}
            >
              <img 
                src={cat.image_url} 
                alt={cat.Category_Name} 
                style={{ width: '28px', height: '28px', borderRadius: '50%', objectFit: 'cover' }} 
              />
              <span>{cat.Category_Name}</span>
            </button>
          ))}
        </aside>

        {/* Cake Cards Grid */}
        <main style={{ gridColumn: 'span 2', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div style={{ fontSize: '0.9rem', color: '#795548', fontWeight: 500 }}>
            Hiển thị <strong>{filteredTemplates.length}</strong> mẫu bánh phù hợp
          </div>

          {filteredTemplates.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '3rem', backgroundColor: '#ffffff', borderRadius: '16px', border: '1px dashed #efebe9', color: '#9e9e9e' }}>
              <span style={{ fontSize: '3rem' }}>🧁</span>
              <p style={{ marginTop: '1rem', color: '#5d4037' }}>Không tìm thấy mẫu bánh nào phù hợp.</p>
              <button 
                onClick={() => { setSearchTerm(''); setSelectedCategory('ALL'); }}
                style={{ marginTop: '0.5rem', padding: '0.5rem 1.25rem', border: '1px solid #d84315', borderRadius: '6px', backgroundColor: 'transparent', color: '#d84315', cursor: 'pointer', fontWeight: 600 }}
              >
                Đặt lại bộ lọc
              </button>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1.5rem' }}>
              {filteredTemplates.map(tpl => (
                <div 
                  key={tpl.Template_ID}
                  onClick={() => navigate(`/products/${tpl.Template_ID}`)}
                  style={{ 
                    backgroundColor: '#ffffff', 
                    borderRadius: '16px', 
                    border: '1px solid #efebe9', 
                    overflow: 'hidden', 
                    boxShadow: '0 4px 15px rgba(62, 39, 35, 0.02)', 
                    display: 'flex', 
                    flexDirection: 'column',
                    cursor: 'pointer',
                    transition: 'transform 0.2s, box-shadow 0.2s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-4px)';
                    e.currentTarget.style.boxShadow = '0 10px 25px rgba(62, 39, 35, 0.08)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 4px 15px rgba(62, 39, 35, 0.02)';
                  }}
                >
                  <div style={{ position: 'relative', width: '100%', height: '200px', overflow: 'hidden' }}>
                    <img 
                      src={tpl.Image_URL} 
                      alt={tpl.Template_Name} 
                      onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800'; }}
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
                    />
                    {tpl.Is_Featured === 1 && (
                      <span style={{ position: 'absolute', top: '10px', left: '10px', fontSize: '0.75rem', backgroundColor: '#fff3e0', color: '#ff8f00', padding: '3px 8px', borderRadius: '12px', fontWeight: 'bold' }}>
                        ⭐ Nổi bật
                      </span>
                    )}
                  </div>

                  <div style={{ padding: '1.25rem', flex: 1, display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <h3 style={{ margin: 0, fontSize: '1.1rem', color: '#3e2723', fontWeight: 700 }}>
                      {tpl.Template_Name}
                    </h3>
                    
                    <p style={{ margin: 0, fontSize: '0.85rem', color: '#795548', flex: 1, lineHeight: '1.4' }}>
                      {tpl.Full_Description}
                    </p>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.75rem', borderTop: '1px solid #f5f5f5', paddingTop: '0.75rem' }}>
                      <span style={{ fontSize: '1.2rem', color: '#d84315', fontWeight: 800 }}>
                        {Number(tpl.Price || 250000).toLocaleString('vi-VN')} VND
                      </span>

                      {user?.Role_ID !== 'R01' ? (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/custom-cake?templateId=${tpl.Template_ID}`);
                          }}
                          style={{ 
                            padding: '0.4rem 0.8rem', 
                            backgroundColor: '#ff8f00', 
                            color: '#ffffff', 
                            border: 'none', 
                            borderRadius: '6px', 
                            fontWeight: 'bold', 
                            fontSize: '0.8rem',
                            cursor: 'pointer'
                          }}
                        >
                          🎨 Tự thiết kế
                        </button>
                      ) : (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/products/${tpl.Template_ID}`);
                          }}
                          style={{ 
                            padding: '0.4rem 0.8rem', 
                            backgroundColor: '#efebe9', 
                            color: '#5d4037', 
                            border: 'none', 
                            borderRadius: '6px', 
                            fontWeight: 'bold', 
                            fontSize: '0.8rem',
                            cursor: 'pointer'
                          }}
                        >
                          👁️ Chi tiết
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>

    </div>
  );
};

export default ProductList;
