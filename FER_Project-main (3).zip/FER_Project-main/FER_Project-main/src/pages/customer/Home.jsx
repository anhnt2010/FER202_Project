import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { cakeService } from '../../services/cakeService';
import { useAuth } from '../../context/AuthContext';

export const Home = () => {
  const [categories, setCategories] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [selectedCat, setSelectedCat] = useState(null);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    setCategories(cakeService.getCategories());
    setTemplates(cakeService.getTemplates());
  }, []);

  const handleCategoryClick = (catId) => {
    setSelectedCat(catId);
    setTemplates(cakeService.getTemplates(catId));
  };

  const clearFilter = () => {
    setSelectedCat(null);
    setTemplates(cakeService.getTemplates());
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '3rem', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Hero Banner */}
      <section style={{ 
        background: 'linear-gradient(135deg, #efebe9 0%, #d7ccc8 100%)', 
        borderRadius: '20px', padding: '3.5rem 2rem', textAlign: 'center',
        boxShadow: '0 8px 30px rgba(62, 39, 35, 0.04)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem'
      }}>
        <h1 style={{ margin: 0, fontSize: '2.5rem', fontWeight: 900, color: '#3e2723' }}>Tự Tay Thiết Kế Chiếc Bánh Kem Mơ Ước</h1>
        <p style={{ margin: 0, fontSize: '1.1rem', color: '#5d4037', maxWidth: '600px', lineHeight: '1.6' }}>
          Chọn từ các mẫu bánh kem sinh nhật nghệ thuật hoặc tự phối ghép hương vị cốt bánh, kem phủ và lời chúc theo ý thích của bạn.
        </p>
        {user?.Role_ID !== 'R01' ? (
          <button 
            onClick={() => navigate('/custom-cake')}
            style={{ 
              marginTop: '1rem', padding: '0.9rem 2.2rem', backgroundColor: '#d84315', color: '#ffffff', 
              border: 'none', borderRadius: '30px', fontSize: '1.1rem', fontWeight: 'bold', 
              cursor: 'pointer', boxShadow: '0 6px 20px rgba(216, 67, 21, 0.3)', transition: 'transform 0.2s'
            }}
          >
            🎨 Bắt đầu thiết kế bánh ngay
          </button>
        ) : (
          <button 
            onClick={() => navigate('/admin')}
            style={{ 
              marginTop: '1rem', padding: '0.9rem 2.2rem', backgroundColor: '#1a1a24', color: '#ffb74d', 
              border: 'none', borderRadius: '30px', fontSize: '1rem', fontWeight: 'bold', 
              cursor: 'pointer', boxShadow: '0 6px 20px rgba(0, 0, 0, 0.15)'
            }}
          >
            ⚙️ Đến trang Quản lý Admin
          </button>
        )}
      </section>

      {/* Categories Section */}
      <section>
        <h2 style={{ fontSize: '1.5rem', color: '#3e2723', marginBottom: '1.5rem' }}>Danh mục sản phẩm</h2>
        <div style={{ display: 'flex', gap: '1.5rem', overflowX: 'auto', paddingBottom: '0.5rem' }}>
          <div 
            onClick={clearFilter}
            style={{ 
              ...catCardStyle,
              borderColor: !selectedCat ? '#d84315' : '#e0e0e0',
              backgroundColor: !selectedCat ? '#fdf8f5' : '#ffffff'
            }}
          >
            <div style={{ fontSize: '2rem' }}>🎂</div>
            <div style={{ fontWeight: 'bold', marginTop: '0.5rem', textAlign: 'center' }}>Tất cả mẫu bánh</div>
          </div>
          {categories.map(cat => (
            <div 
              key={cat.Category_ID}
              onClick={() => handleCategoryClick(cat.Category_ID)}
              style={{ 
                ...catCardStyle,
                borderColor: selectedCat === cat.Category_ID ? '#d84315' : '#e0e0e0',
                backgroundColor: selectedCat === cat.Category_ID ? '#fdf8f5' : '#ffffff'
              }}
            >
              <img src={cat.image_url} alt={cat.Category_Name} style={{ width: '50px', height: '50px', borderRadius: '50%', objectFit: 'cover' }} />
              <div style={{ fontWeight: 'bold', marginTop: '0.5rem', textAlign: 'center' }}>{cat.Category_Name}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Popular Templates Section */}
      <section>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.5rem', color: '#3e2723', margin: 0 }}>Mẫu bánh kem phổ biến</h2>
          <button 
            onClick={() => navigate('/products')}
            style={{ backgroundColor: 'transparent', border: 'none', color: '#d84315', fontWeight: 'bold', cursor: 'pointer', fontSize: '0.95rem' }}
          >
            Xem tất cả ➔
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '2rem' }}>
          {templates.map(tpl => (
            <div 
              key={tpl.Template_ID} 
              onClick={() => navigate(`/products/${tpl.Template_ID}`)}
              style={{ 
                backgroundColor: '#ffffff', 
                borderRadius: '16px', 
                border: '1px solid #efebe9', 
                overflow: 'hidden', 
                boxShadow: '0 4px 15px rgba(62, 39, 35, 0.02)', 
                display: 'flex', 
                flexDirection: 'column',
                cursor: 'pointer',
                transition: 'transform 0.2s, box-shadow 0.2s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)';
                e.currentTarget.style.boxShadow = '0 10px 25px rgba(62, 39, 35, 0.08)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 4px 15px rgba(62, 39, 35, 0.02)';
              }}
            >
              <img 
                src={tpl.Image_URL} 
                alt={tpl.Template_Name} 
                onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800'; }}
                style={{ width: '100%', height: '200px', objectFit: 'cover' }} 
              />
              <div style={{ padding: '1.25rem', flex: 1, display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h3 style={{ margin: 0, fontSize: '1.1rem', color: '#3e2723' }}>{tpl.Template_Name}</h3>
                  {tpl.Is_Featured === 1 && <span style={{ fontSize: '0.75rem', backgroundColor: '#fff3e0', color: '#ff8f00', padding: '2px 8px', borderRadius: '12px', fontWeight: 'bold' }}>Nổi bật</span>}
                </div>
                <p style={{ margin: 0, fontSize: '0.85rem', color: '#795548', flex: 1, lineHeight: '1.4' }}>
                  {tpl.Full_Description}
                </p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem', borderTop: '1px solid #f5f5f5', paddingTop: '0.75rem' }}>
                  <span style={{ fontSize: '1.2rem', color: '#d84315', fontWeight: 800 }}>
                    {Number(tpl.Price || 250000).toLocaleString('vi-VN')} VND
                  </span>
                  {user?.Role_ID !== 'R01' ? (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/custom-cake?templateId=${tpl.Template_ID}`);
                      }}
                      style={{ 
                        padding: '0.4rem 0.8rem', backgroundColor: '#ff8f00', color: '#ffffff', 
                        border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', fontSize: '0.85rem'
                      }}
                    >
                      🎨 Custom
                    </button>
                  ) : (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/products/${tpl.Template_ID}`);
                      }}
                      style={{ 
                        padding: '0.4rem 0.8rem', backgroundColor: '#efebe9', color: '#5d4037', 
                        border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', fontSize: '0.85rem'
                      }}
                    >
                      👁️ Chi tiết
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

const catCardStyle = {
  flex: '0 0 140px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  padding: '1rem',
  border: '2px solid #e0e0e0',
  borderRadius: '12px',
  cursor: 'pointer',
  transition: 'all 0.2s',
  userSelect: 'none'
};

export default Home;
