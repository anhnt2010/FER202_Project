import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { cakeService } from '../../services/cakeService';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';

export const CustomCakeDesigner = () => {
  const [searchParams] = useSearchParams();
  const templateId = searchParams.get('templateId') || 'TPL-001';
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { user } = useAuth();

  useEffect(() => {
    if (user?.Role_ID === 'R01') {
      alert('Tài khoản Quản trị viên không được phép thiết kế bánh!');
      navigate('/admin');
    }
  }, [user, navigate]);

  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  // Custom Choices
  const [layerCount, setLayerCount] = useState(2);
  const [flavour, setFlavour] = useState('Vanilla');
  const [frosting, setFrosting] = useState('Kem Whipping tươi');
  const [topping, setTopping] = useState('Dâu tây tươi');
  const [greetingText, setGreetingText] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [totalPrice, setTotalPrice] = useState(250000);

  useEffect(() => {
    const tpls = cakeService.getTemplates();
    setTemplates(tpls);
    const tpl = cakeService.getTemplateById(templateId) || tpls[0];
    if (tpl) {
      setSelectedTemplate(tpl);
    }
  }, [templateId]);

  // Recalculate price simply
  useEffect(() => {
    if (selectedTemplate) {
      const base = Number(selectedTemplate.Price || 250000);
      const extraLayerFee = layerCount > 2 ? (layerCount - 2) * 30000 : 0;
      const frostingFee = frosting === 'Kem Phô Mai (Cream Cheese)' ? 20000 : 0;
      const toppingFee = topping !== 'Không có topping' ? 20000 : 0;
      setTotalPrice(base + extraLayerFee + frostingFee + toppingFee);
    }
  }, [selectedTemplate, layerCount, frosting, topping]);

  const handleTemplateChange = (e) => {
    const tplId = e.target.value;
    navigate(`/custom-cake?templateId=${tplId}`);
  };

  const handleAddToCart = () => {
    if (!selectedTemplate) return;

    addToCart({
      Template_ID: selectedTemplate.Template_ID,
      Template_Name: `Bánh Custom: ${selectedTemplate.Template_Name}`,
      Price: totalPrice,
      Quantity: quantity,
      Greeting_Text: greetingText,
      Flavour: `${flavour} (${layerCount} tầng)`,
      Frosting: `${frosting} + ${topping}`,
      Image_URL: selectedTemplate.Image_URL
    });

    navigate('/cart');
  };

  const getFlavourColor = () => {
    switch (flavour) {
      case 'Chocolate': return '#5d4037';
      case 'Matcha': return '#689f38';
      case 'Dâu tây': return '#f48fb1';
      default: return '#ffe0b2'; // Vanilla
    }
  };

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', fontFamily: 'Inter, sans-serif' }}>
      <h1 style={{ fontSize: '1.8rem', color: '#3e2723', marginBottom: '1.5rem' }}>
        🎨 Bộ Thiết Kế Bánh Kem Cá Nhân Hóa
      </h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem', alignItems: 'start' }}>
        
        {/* Left Side: Live Cake Preview */}
        <div style={{ backgroundColor: '#ffffff', borderRadius: '16px', padding: '2rem', border: '1px solid #efebe9', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
          <h3 style={{ margin: '0 0 1.5rem 0', color: '#5d4037' }}>Mô phỏng bánh kem</h3>

          {/* Graphical Stack */}
          <div style={{ display: 'flex', flexDirection: 'column-reverse', alignItems: 'center', width: '220px', gap: '6px', margin: '2rem 0' }}>
            {Array.from({ length: layerCount }).map((_, index) => (
              <div
                key={index}
                style={{
                  width: `${160 + index * 20}px`,
                  height: '38px',
                  backgroundColor: getFlavourColor(),
                  borderRadius: '8px',
                  border: '2px solid #ffffff',
                  boxShadow: '0 4px 6px rgba(0,0,0,0.06)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: flavour === 'Chocolate' ? '#ffffff' : '#3e2723',
                  fontSize: '0.85rem',
                  fontWeight: 'bold'
                }}
              >
                Tầng {index + 1}: {flavour}
              </div>
            ))}

            {/* Frosting Top */}
            <div style={{
              width: `${160 + layerCount * 20}px`,
              height: '14px',
              backgroundColor: frosting.includes('Phô Mai') ? '#fff9c4' : '#fff3e0',
              border: '2px solid #ffffff',
              borderRadius: '8px 8px 0 0',
              marginTop: '-8px'
            }} />
          </div>

          {/* Topping and Greeting preview */}
          {topping !== 'Không có topping' && (
            <div style={{ fontSize: '0.9rem', color: '#d84315', fontWeight: 'bold', marginBottom: '0.5rem' }}>
              🍒 Topping: {topping}
            </div>
          )}

          {greetingText && (
            <div style={{
              marginTop: '0.5rem',
              fontStyle: 'italic',
              fontSize: '1.05rem',
              color: '#d84315',
              border: '1px dashed #d84315',
              padding: '0.5rem 1rem',
              borderRadius: '6px',
              backgroundColor: '#fff8f6'
            }}>
              "{greetingText}"
            </div>
          )}
        </div>

        {/* Right Side: Options Form */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          
          {/* Base Template */}
          <div style={panelStyle}>
            <label style={labelStyle}>Mẫu thiết kế cơ sở</label>
            <select value={selectedTemplate?.Template_ID || templateId} onChange={handleTemplateChange} style={selectStyle}>
              {templates.map(t => (
                <option key={t.Template_ID} value={t.Template_ID}>
                  {t.Template_Name} - ({Number(t.Price || 250000).toLocaleString('vi-VN')} VND)
                </option>
              ))}
            </select>
          </div>

          {/* Flavor and Layer Count */}
          <div style={panelStyle}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label style={labelStyle}>Vị cốt bông lan</label>
                <select value={flavour} onChange={e => setFlavour(e.target.value)} style={selectStyle}>
                  <option value="Vanilla">Vanilla truyền thống</option>
                  <option value="Chocolate">Chocolate hảo hạng</option>
                  <option value="Matcha">Trà xanh Matcha</option>
                  <option value="Dâu tây">Dâu tây ngọt dịu</option>
                </select>
              </div>

              <div>
                <label style={labelStyle}>Số tầng bánh</label>
                <select value={layerCount} onChange={e => setLayerCount(Number(e.target.value))} style={selectStyle}>
                  <option value={1}>1 tầng</option>
                  <option value={2}>2 tầng (Tiêu chuẩn)</option>
                  <option value={3}>3 tầng (+30.000 VND)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Frosting and Topping */}
          <div style={panelStyle}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label style={labelStyle}>Kem phủ bánh</label>
                <select value={frosting} onChange={e => setFrosting(e.target.value)} style={selectStyle}>
                  <option value="Kem Whipping tươi">Kem Whipping tươi</option>
                  <option value="Kem Phô Mai (Cream Cheese)">Kem Phô Mai (+20.000)</option>
                  <option value="Kem Bơ truyền thống">Kem Bơ truyền thống</option>
                </select>
              </div>

              <div>
                <label style={labelStyle}>Topping trang trí</label>
                <select value={topping} onChange={e => setTopping(e.target.value)} style={selectStyle}>
                  <option value="Dâu tây tươi">Dâu tây tươi (+20.000)</option>
                  <option value="Việt quất">Việt quất nhập khẩu (+20.000)</option>
                  <option value="Hạt Chocolate chip">Hạt Chocolate chip (+20.000)</option>
                  <option value="Không có topping">Không có topping</option>
                </select>
              </div>
            </div>
          </div>

          {/* Greeting Text */}
          <div style={panelStyle}>
            <label style={labelStyle}>Chữ ghi trên bánh (Miễn phí)</label>
            <input
              type="text"
              maxLength={40}
              placeholder="VD: Chúc mừng sinh nhật bé Bông tròn 3 tuổi!"
              value={greetingText}
              onChange={e => setGreetingText(e.target.value)}
              style={inputStyle}
            />
          </div>

          {/* Order Summary & Submit */}
          <div style={{
            backgroundColor: '#3e2723',
            color: '#ffffff',
            borderRadius: '12px',
            padding: '1.25rem 1.5rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '1rem'
          }}>
            <div>
              <div style={{ fontSize: '0.85rem', color: '#b0bec5' }}>Giá bánh tùy chỉnh:</div>
              <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#ff8f00' }}>
                {(totalPrice * quantity).toLocaleString('vi-VN')} VND
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <input
                type="number"
                min={1}
                value={quantity}
                onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                style={{ width: '50px', padding: '0.5rem', borderRadius: '6px', border: 'none', textAlign: 'center', fontWeight: 'bold' }}
              />
              <button
                onClick={handleAddToCart}
                style={{
                  padding: '0.8rem 1.5rem',
                  backgroundColor: '#d84315',
                  color: '#ffffff',
                  border: 'none',
                  borderRadius: '8px',
                  fontWeight: 'bold',
                  cursor: 'pointer'
                }}
              >
                🛒 Thêm vào giỏ hàng
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

const panelStyle = {
  backgroundColor: '#ffffff',
  padding: '1.25rem',
  borderRadius: '12px',
  border: '1px solid #efebe9'
};

const labelStyle = {
  display: 'block',
  marginBottom: '0.4rem',
  fontSize: '0.85rem',
  fontWeight: 'bold',
  color: '#5d4037'
};

const selectStyle = {
  width: '100%',
  padding: '0.6rem',
  borderRadius: '8px',
  border: '1px solid #d7ccc8',
  backgroundColor: '#ffffff',
  outline: 'none',
  fontSize: '0.9rem'
};

const inputStyle = {
  width: '100%',
  padding: '0.6rem 0.8rem',
  borderRadius: '8px',
  border: '1px solid #d7ccc8',
  outline: 'none',
  boxSizing: 'border-box',
  fontSize: '0.9rem'
};

export default CustomCakeDesigner;
