import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { orderService } from '../../services/orderService';

export const OrderHistory = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const customerId = user?.details?.Customer_ID || (user?.User_ID ? 'CUS-' + user.User_ID.replace('U', '') : 'CUS-001');
    if (customerId) {
      setOrders(orderService.getOrdersByCustomer(customerId));
    }
  }, [user]);

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleString('vi-VN', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit'
    });
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Completed':
        return { label: 'Đã hoàn thành', bg: '#e8f5e9', color: '#2e7d32' };
      case 'Processing':
        return { label: 'Đang làm bánh', bg: '#e3f2fd', color: '#1565c0' };
      case 'Canceled':
        return { label: 'Đã hủy', bg: '#ffebee', color: '#c62828' };
      default:
        return { label: 'Đang chờ xác nhận', bg: '#fff3e0', color: '#ef6c00' };
    }
  };

  if (!user) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem', fontFamily: 'Inter, sans-serif' }}>
        <h2>Vui lòng đăng nhập để xem lịch sử đơn hàng</h2>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '850px', margin: '0 auto', fontFamily: 'Inter, sans-serif' }}>
      <h1 style={{ fontSize: '1.8rem', color: '#3e2723', marginBottom: '1.5rem' }}>📦 Lịch sử đặt hàng của bạn</h1>

      {orders.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '3rem', backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #efebe9' }}>
          <p style={{ color: '#795548', margin: 0 }}>Bạn chưa có đơn đặt hàng nào.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {orders.map(order => {
            const badge = getStatusBadge(order.OrderStatus);
            return (
              <div key={order.Order_No} style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '1.5rem', border: '1px solid #efebe9', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}>
                {/* Header */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #efebe9', paddingBottom: '0.75rem', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div>
                    <strong style={{ fontSize: '1.1rem', color: '#3e2723' }}>Mã đơn: {order.Order_No}</strong>
                    <span style={{ fontSize: '0.85rem', color: '#795548', marginLeft: '1rem' }}>
                      Đặt lúc: {formatDate(order.Order_Date)}
                    </span>
                  </div>
                  <span style={{ 
                    backgroundColor: badge.bg, 
                    color: badge.color, 
                    padding: '4px 12px', 
                    borderRadius: '20px', 
                    fontWeight: 'bold', 
                    fontSize: '0.85rem' 
                  }}>
                    {badge.label}
                  </span>
                </div>

                {/* Items */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1rem' }}>
                  {order.Items.map((item, idx) => (
                    <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.95rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                      <div>
                        <strong>🎂 {item.Template_Name}</strong>
                        {item.Flavour && (
                          <span style={{ fontSize: '0.85rem', color: '#795548', marginLeft: '6px' }}>({item.Flavour})</span>
                        )}
                        {item.Greeting_Text && (
                          <div style={{ color: '#d84315', fontStyle: 'italic', fontSize: '0.85rem' }}>
                            Chữ: "{item.Greeting_Text}"
                          </div>
                        )}
                        {order.OrderStatus === 'Completed' && item.Template_ID?.startsWith('TPL-') && (
                          <Link 
                            to={`/products/${item.Template_ID}`}
                            style={{ 
                              display: 'inline-block', 
                              marginTop: '4px',
                              fontSize: '0.8rem', 
                              color: '#d84315', 
                              textDecoration: 'none', 
                              fontWeight: 'bold',
                              border: '1px solid #ffd0b0',
                              borderRadius: '4px',
                              padding: '2px 8px',
                              backgroundColor: '#fff9f5'
                            }}
                          >
                            ⭐ Đánh giá mẫu bánh này
                          </Link>
                        )}
                        <span style={{ fontSize: '0.85rem', color: '#795548', marginLeft: '0.5rem' }}>x {item.Quantity}</span>
                      </div>
                      <span style={{ fontWeight: 600 }}>{(item.Price * item.Quantity).toLocaleString('vi-VN')} VND</span>
                    </div>
                  ))}
                </div>

                {/* Footer */}
                <div style={{ borderTop: '1px solid #f5f5f5', paddingTop: '0.75rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div style={{ fontSize: '0.85rem', color: '#5d4037' }}>
                    📍 <strong>Địa chỉ giao:</strong> {order.Delivery_Address}
                  </div>
                  <div style={{ fontSize: '1.2rem', fontWeight: 900, color: '#d84315' }}>
                    Tổng: {Number(order.Total_Price).toLocaleString('vi-VN')} VND
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default OrderHistory;
