import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { cakeService } from '../../services/cakeService';
import { reviewService } from '../../services/reviewService';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';

export const ProductDetail = () => {
  const { id: templateId } = useParams();
  const { user } = useAuth();
  const { addToCart } = useCart();
  const navigate = useNavigate();

  const [template, setTemplate] = useState(null);
  const [categoryName, setCategoryName] = useState('');
  const [relatedProducts, setRelatedProducts] = useState([]);
  
  // Image gallery
  const [images, setImages] = useState([]);
  const [activeImage, setActiveImage] = useState('');

  // Review states
  const [reviews, setReviews] = useState([]);
  const [hasBought, setHasBought] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);
  
  // New review form
  const [ratingStars, setRatingStars] = useState(5);
  const [comment, setComment] = useState('');
  const [reviewError, setReviewError] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);

  useEffect(() => {
    const tpl = cakeService.getTemplateById(templateId);
    if (!tpl || tpl.Status !== 'Active') {
      navigate('/products');
      return;
    }
    
    document.title = `${tpl.Template_Name} - BakeryZone`;
    setTemplate(tpl);

    // Get Category Name
    const categories = cakeService.getCategories();
    const cat = categories.find(c => c.Category_ID === tpl.Category_ID);
    setCategoryName(cat ? cat.Category_Name : 'Bánh kem');

    // Get Related Products
    const allTemplates = cakeService.getTemplates();
    const related = allTemplates
      .filter(t => t.Category_ID === tpl.Category_ID && t.Template_ID !== tpl.Template_ID)
      .slice(0, 4);
    setRelatedProducts(related);

    // Images
    const imgList = [tpl.Image_URL];
    imgList.push('https://images.unsplash.com/photo-1535141192574-5d4897c13636?w=800');
    imgList.push('https://images.unsplash.com/photo-1557925923-cd4648e21187?w=800');
    setImages(imgList);
    setActiveImage(imgList[0]);

    // Reviews
    const productReviews = reviewService.getReviewsByProductId(templateId);
    setReviews(productReviews);

    // Review eligibility
    if (user && user.details?.Customer_ID) {
      const bought = reviewService.hasBoughtProduct(user.details.Customer_ID, templateId);
      const reviewed = reviewService.hasReviewed(user.details.Customer_ID, templateId);
      setHasBought(bought);
      setHasReviewed(reviewed);
    } else {
      setHasBought(false);
      setHasReviewed(false);
    }
  }, [templateId, user, navigate]);

  const handleQuickAddToCart = () => {
    if (!template) return;
    addToCart({
      Template_ID: template.Template_ID,
      Template_Name: template.Template_Name,
      Price: Number(template.Price || 250000),
      Quantity: 1,
      Greeting_Text: '',
      Flavour: 'Tiêu chuẩn',
      Frosting: 'Kem truyền thống',
      Image_URL: template.Image_URL
    });
    navigate('/cart');
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    setReviewError('');

    if (!comment.trim()) {
      setReviewError('Vui lòng nhập nhận xét của bạn.');
      return;
    }

    try {
      const reviewItem = reviewService.addReview(
        user.details.Customer_ID,
        user.details.Full_Name || user.Email,
        templateId,
        ratingStars,
        comment
      );

      setReviews([...reviews, reviewItem]);
      setHasReviewed(true);
      setReviewSuccess(true);
      setComment('');
    } catch (err) {
      setReviewError('Đã có lỗi: ' + err.message);
    }
  };

  if (!template) {
    return <div style={{ textAlign: 'center', padding: '3rem' }}>Đang tải thông tin sản phẩm...</div>;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '3rem', maxWidth: '1100px', margin: '0 auto' }}>
      
      {/* Back button */}
      <div>
        <Link 
          to="/products" 
          style={{ textDecoration: 'none', color: '#5d4037', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}
        >
          <span>⬅️</span> Quay lại danh sách mẫu bánh
        </Link>
      </div>

      {/* Main product display */}
      <section style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', 
        gap: '2.5rem',
        backgroundColor: '#ffffff',
        padding: '2rem',
        borderRadius: '20px',
        boxShadow: '0 8px 30px rgba(62, 39, 35, 0.03)'
      }}>
        {/* Left Side: Image Gallery */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ width: '100%', height: '360px', borderRadius: '16px', overflow: 'hidden', border: '1px solid #efebe9' }}>
            <img 
              src={activeImage} 
              alt={template.Template_Name} 
              onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800'; }}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
            />
          </div>
          {/* Thumbnails */}
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            {images.map((img, idx) => (
              <div 
                key={idx}
                onClick={() => setActiveImage(img)}
                style={{
                  width: '75px',
                  height: '75px',
                  borderRadius: '10px',
                  overflow: 'hidden',
                  cursor: 'pointer',
                  border: activeImage === img ? '2px solid #d84315' : '2px solid transparent',
                  opacity: activeImage === img ? 1 : 0.6
                }}
              >
                <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Product Info */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', justifyContent: 'space-between' }}>
          <div>
            <span style={{ fontSize: '0.85rem', backgroundColor: '#efebe9', color: '#5d4037', padding: '4px 12px', borderRadius: '12px', fontWeight: 600 }}>
              {categoryName}
            </span>
            
            <h1 style={{ margin: '0.75rem 0 0.5rem 0', fontSize: '1.8rem', fontWeight: 800, color: '#3e2723' }}>
              {template.Template_Name}
            </h1>

            {/* Stars summary */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '1rem' }}>
              <span style={{ color: '#ffc107', fontSize: '1.1rem' }}>
                {'★'.repeat(reviews.length > 0 ? Math.round(reviews.reduce((sum, r) => sum + r.Rating_Stars, 0) / reviews.length) : 5)}
              </span>
              <span style={{ fontSize: '0.85rem', color: '#795548', fontWeight: 500 }}>
                ({reviews.length} đánh giá)
              </span>
            </div>

            <div style={{ fontSize: '1.8rem', color: '#d84315', fontWeight: 800, marginBottom: '1rem' }}>
              {Number(template.Price || 250000).toLocaleString('vi-VN')} VND
            </div>

            <p style={{ fontSize: '0.95rem', color: '#5d4037', lineHeight: '1.6', borderTop: '1px solid #f5f5f5', paddingTop: '1rem' }}>
              {template.Full_Description}
            </p>
          </div>

          <div style={{ borderTop: '1px solid #f5f5f5', paddingTop: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {user?.Role_ID === 'R01' ? (
              <div style={{ 
                padding: '1rem 1.25rem', 
                backgroundColor: '#fff3e0', 
                color: '#e65100', 
                borderRadius: '10px', 
                fontSize: '0.9rem', 
                fontWeight: 600,
                border: '1px solid #ffe0b2',
                lineHeight: '1.5'
              }}>
                🔒 Tài khoản Quản trị viên chỉ có quyền xem và quản lý mẫu bánh, không được phép thiết kế hoặc đặt mua bánh.
              </div>
            ) : (
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <button
                  onClick={handleQuickAddToCart}
                  style={{
                    flex: 1,
                    minWidth: '180px',
                    padding: '0.85rem 1.25rem',
                    backgroundColor: '#ff8f00',
                    color: '#ffffff',
                    border: 'none',
                    borderRadius: '10px',
                    fontWeight: 'bold',
                    fontSize: '0.95rem',
                    cursor: 'pointer'
                  }}
                >
                  🛒 Đặt nhanh mẫu này
                </button>

                <button
                  onClick={() => navigate(`/custom-cake?templateId=${template.Template_ID}`)}
                  style={{
                    flex: 1.2,
                    minWidth: '200px',
                    padding: '0.85rem 1.25rem',
                    backgroundColor: '#d84315',
                    color: '#ffffff',
                    border: 'none',
                    borderRadius: '10px',
                    fontWeight: 'bold',
                    fontSize: '0.95rem',
                    cursor: 'pointer'
                  }}
                >
                  🎨 Tự chọn cốt bánh & lời chúc
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Reviews & Form */}
      <section style={{ 
        backgroundColor: '#ffffff', 
        padding: '2rem', 
        borderRadius: '20px', 
        boxShadow: '0 8px 30px rgba(62, 39, 35, 0.03)',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '2.5rem'
      }}>
        {/* Customer reviews list */}
        <div>
          <h2 style={{ margin: '0 0 1.25rem 0', fontSize: '1.3rem', color: '#3e2723', fontWeight: 800 }}>
            Đánh giá từ khách hàng ({reviews.length})
          </h2>

          {reviews.length === 0 ? (
            <p style={{ color: '#9e9e9e', margin: 0 }}>Chưa có đánh giá nào cho mẫu bánh này.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {reviews.map(r => (
                <div key={r.Review_ID} style={{ borderBottom: '1px solid #f5f5f5', paddingBottom: '1rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong style={{ color: '#3e2723', fontSize: '0.95rem' }}>{r.Customer_Name}</strong>
                    <span style={{ fontSize: '0.8rem', color: '#bdbdbd' }}>
                      {new Date(r.Review_Date).toLocaleDateString('vi-VN')}
                    </span>
                  </div>
                  <div style={{ color: '#ffc107', fontSize: '0.9rem', margin: '4px 0' }}>
                    {'★'.repeat(r.Rating_Stars)}
                  </div>
                  <p style={{ margin: 0, fontSize: '0.9rem', color: '#5d4037', lineHeight: '1.4' }}>
                    {r.Comment}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Writing review form */}
        <div style={{ borderLeft: '1px solid #f5f5f5', paddingLeft: '1.5rem' }}>
          <h2 style={{ margin: '0 0 1.25rem 0', fontSize: '1.3rem', color: '#3e2723', fontWeight: 800 }}>
            Gửi nhận xét của bạn
          </h2>

          {!user ? (
            <div style={{ backgroundColor: '#faf6f0', padding: '1.25rem', borderRadius: '10px', textAlign: 'center' }}>
              <p style={{ margin: '0 0 1rem 0', color: '#5d4037', fontSize: '0.9rem' }}>Vui lòng đăng nhập để đánh giá.</p>
              <Link to="/auth/login" style={{ padding: '0.4rem 1.2rem', backgroundColor: '#d84315', color: '#fff', textDecoration: 'none', borderRadius: '6px', fontWeight: 'bold', fontSize: '0.85rem' }}>
                Đăng nhập
              </Link>
            </div>
          ) : !hasBought ? (
            <div style={{ backgroundColor: '#fff3e0', padding: '1rem', borderRadius: '10px', color: '#e65100', fontSize: '0.9rem' }}>
              ℹ️ Bạn cần đặt mua mẫu bánh này trước khi gửi đánh giá.
            </div>
          ) : hasReviewed ? (
            <div style={{ backgroundColor: '#e8f5e9', padding: '1rem', borderRadius: '10px', color: '#2e7d32', fontSize: '0.9rem' }}>
              ✅ Bạn đã gửi đánh giá cho mẫu bánh này. Cảm ơn bạn!
            </div>
          ) : (
            <form onSubmit={handleReviewSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {reviewSuccess && <div style={{ color: '#2e7d32', fontSize: '0.9rem' }}>Đã gửi đánh giá thành công!</div>}
              {reviewError && <div style={{ color: '#c62828', fontSize: '0.9rem' }}>{reviewError}</div>}

              <div>
                <label style={{ fontSize: '0.85rem', fontWeight: 600, color: '#5d4037' }}>Số sao:</label>
                <div style={{ display: 'flex', gap: '4px', marginTop: '4px' }}>
                  {[1, 2, 3, 4, 5].map(star => (
                    <span 
                      key={star}
                      onClick={() => setRatingStars(star)}
                      style={{ fontSize: '1.6rem', cursor: 'pointer', color: star <= ratingStars ? '#ffc107' : '#e0e0e0' }}
                    >
                      ★
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.85rem', fontWeight: 600, color: '#5d4037' }}>Bình luận:</label>
                <textarea
                  rows={3}
                  placeholder="Cảm nhận của bạn về bánh..."
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  style={{ width: '100%', padding: '0.6rem', borderRadius: '8px', border: '1px solid #efebe9', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' }}
                  required
                />
              </div>

              <button
                type="submit"
                style={{ padding: '0.6rem 1.25rem', backgroundColor: '#d84315', color: '#ffffff', border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer', alignSelf: 'flex-start' }}
              >
                Gửi đánh giá
              </button>
            </form>
          )}
        </div>
      </section>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <section>
          <h2 style={{ fontSize: '1.3rem', color: '#3e2723', marginBottom: '1.25rem', fontWeight: 800 }}>
            Sản phẩm cùng danh mục
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1.5rem' }}>
            {relatedProducts.map(tpl => (
              <div 
                key={tpl.Template_ID}
                onClick={() => navigate(`/products/${tpl.Template_ID}`)}
                style={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #efebe9', overflow: 'hidden', cursor: 'pointer' }}
              >
                <img src={tpl.Image_URL} alt="" style={{ width: '100%', height: '140px', objectFit: 'cover' }} />
                <div style={{ padding: '0.75rem' }}>
                  <div style={{ fontWeight: 700, fontSize: '0.9rem', color: '#3e2723' }}>{tpl.Template_Name}</div>
                  <div style={{ color: '#d84315', fontWeight: 700, fontSize: '0.85rem', marginTop: '0.25rem' }}>
                    {Number(tpl.Price || 250000).toLocaleString('vi-VN')} VND
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

    </div>
  );
};

export default ProductDetail;
