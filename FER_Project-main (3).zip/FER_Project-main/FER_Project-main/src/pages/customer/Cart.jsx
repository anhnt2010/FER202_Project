import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { orderService } from '../../services/orderService';
import { cakeService } from '../../services/cakeService';

export const Cart = () => {
  const { cartItems, addToCart, updateQuantity, removeFromCart, getCartTotal, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [accessoriesList, setAccessoriesList] = useState([]);
  
  // Checkout Form
  const [receiverName, setReceiverName] = useState('');
  const [receiverPhone, setReceiverPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryNote, setDeliveryNote] = useState('');

  useEffect(() => {
    setAccessoriesList(cakeService.getAccessories());
    if (user?.details) {
      setReceiverName(user.details.Full_Name || '');
      setReceiverPhone(user.details.Phone || '');
      setDeliveryAddress(user.details.Default_Address || '');
    }
  }, [user]);

  const handleCheckout = (e) => {
    e.preventDefault();
    if (!user) {
      alert('Vui lòng đăng nhập trước khi đặt hàng!');
      navigate('/auth/login');
      return;
    }
    if (cartItems.length === 0) return;

    try {
      const customerId = user.details?.Customer_ID || 'CUS-001';
      orderService.createOrder(
        customerId,
        receiverName,
        receiverPhone,
        `${deliveryAddress}${deliveryNote ? ` (Ghi chú: ${deliveryNote})` : ''}`,
        cartItems,
        getCartTotal()
      );

      clearCart();
      alert('🎉 Đặt hàng thành công! Đơn hàng của bạn đã được tiếp nhận.');
      navigate('/orders');
    } catch (err) {
      alert('Có lỗi xảy ra: ' + err.message);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 2rem', fontFamily: 'Inter, sans-serif' }}>
        <div style={{ fontSize: '4rem' }}>🛒</div>
        <h2>Giỏ hàng của bạn đang trống</h2>
        <p style={{ color: '#795548', marginBottom: '1.5rem' }}>Hãy chọn mẫu bánh yêu thích để thêm vào giỏ.</p>
        <button 
          onClick={() => navigate('/products')}
          style={{ padding: '0.8rem 2rem', backgroundColor: '#d84315', color: '#fff', border: 'none', borderRadius: '30px', fontWeight: 'bold', cursor: 'pointer' }}
        >
          Khám phá mẫu bánh ngay
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', fontFamily: 'Inter, sans-serif' }}>
      <h1 style={{ fontSize: '1.8rem', color: '#3e2723', marginBottom: '2rem' }}>🛒 Giỏ hàng của bạn</h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '2rem', alignItems: 'start' }}>
        
        {/* Left Side: Items in Cart & Accessories */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {cartItems.map(item => (
            <div key={item.id} style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '1.25rem', border: '1px solid #efebe9', display: 'flex', gap: '1rem', alignItems: 'center' }}>
              <img 
                src={item.Image_URL || 'https://images.unsplash.com/photo-1541417904950-b855846fe074'} 
                alt="" 
                style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '8px' }} 
              />
              
              <div style={{ flex: 1 }}>
                <h4 style={{ margin: 0, fontSize: '1rem', color: '#3e2723' }}>
                  {item.Template_Name}
                </h4>
                {item.Flavour && (
                  <div style={{ fontSize: '0.8rem', color: '#795548', marginTop: '2px' }}>
                    {item.Flavour} {item.Frosting && `| ${item.Frosting}`}
                  </div>
                )}
                {item.Greeting_Text && (
                  <div style={{ fontSize: '0.8rem', color: '#d84315', fontStyle: 'italic', marginTop: '2px' }}>
                    Chữ: "{item.Greeting_Text}"
                  </div>
                )}
                <div style={{ fontSize: '0.95rem', fontWeight: 'bold', color: '#d84315', marginTop: '0.25rem' }}>
                  {Number(item.Price).toLocaleString('vi-VN')} VND
                </div>
              </div>

              {/* Quantity */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <button onClick={() => updateQuantity(item.id, item.Quantity - 1)} style={qtyBtnStyle}>-</button>
                <span style={{ fontWeight: 'bold', width: '25px', textAlign: 'center' }}>{item.Quantity}</span>
                <button onClick={() => updateQuantity(item.id, item.Quantity + 1)} style={qtyBtnStyle}>+</button>
              </div>

              <button 
                onClick={() => removeFromCart(item.id)} 
                style={{ border: 'none', backgroundColor: 'transparent', color: '#ff3333', cursor: 'pointer', fontSize: '1.2rem', padding: '0.5rem' }}
                title="Xóa món"
              >
                🗑️
              </button>
            </div>
          ))}

          {/* Party Accessories */}
          {accessoriesList.length > 0 && (
            <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '1.25rem', border: '1px solid #efebe9', marginTop: '0.5rem' }}>
              <h4 style={{ margin: '0 0 1rem 0', color: '#3e2723', fontSize: '1rem' }}>
                🎉 Thêm phụ kiện bữa tiệc (Nến, Mũ, Đĩa thìa)
              </h4>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))', gap: '0.75rem' }}>
                {accessoriesList.map(acc => (
                  <div key={acc.Accessory_ID} style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', padding: '0.5rem', borderRadius: '8px', border: '1px solid #f0f0f0', backgroundColor: '#fafafa' }}>
                    <img 
                      src={acc.Image_URL} 
                      alt="" 
                      style={{ width: '45px', height: '45px', objectFit: 'cover', borderRadius: '6px' }} 
                    />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#3e2723', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{acc.Accessory_Name}</div>
                      <div style={{ fontSize: '0.8rem', color: '#d84315', fontWeight: 700 }}>{Number(acc.Price).toLocaleString('vi-VN')} VND</div>
                    </div>
                    <button 
                      type="button"
                      onClick={() => addToCart({
                        Template_ID: acc.Accessory_ID,
                        Template_Name: acc.Accessory_Name,
                        Price: acc.Price,
                        Quantity: 1,
                        Image_URL: acc.Image_URL
                      })}
                      style={{ padding: '0.35rem 0.6rem', backgroundColor: '#d84315', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '0.8rem', fontWeight: 'bold' }}
                    >
                      + Thêm
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Simple Checkout Form */}
        <div style={{ backgroundColor: '#ffffff', borderRadius: '16px', padding: '1.5rem', border: '1px solid #efebe9' }}>
          <h3 style={{ margin: '0 0 1.5rem 0', color: '#3e2723', borderBottom: '1px solid #efebe9', paddingBottom: '0.75rem' }}>Thông tin nhận hàng</h3>

          <form onSubmit={handleCheckout} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Họ và tên người nhận</label>
              <input type="text" required value={receiverName} onChange={e => setReceiverName(e.target.value)} style={inputStyle} placeholder="Nguyễn Văn A" />
            </div>

            <div>
              <label style={labelStyle}>Số điện thoại</label>
              <input type="text" required value={receiverPhone} onChange={e => setReceiverPhone(e.target.value)} style={inputStyle} placeholder="0912345678" />
            </div>

            <div>
              <label style={labelStyle}>Địa chỉ giao hàng</label>
              <input type="text" required value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} style={inputStyle} placeholder="Số 123 Đường Lê Lợi, Q.1, TP. HCM" />
            </div>

            <div>
              <label style={labelStyle}>Ghi chú thêm (tùy chọn)</label>
              <input type="text" value={deliveryNote} onChange={e => setDeliveryNote(e.target.value)} style={inputStyle} placeholder="Giao trước 17h, gọi điện trước khi đến..." />
            </div>

            {/* Total Price Display */}
            <div style={{ borderTop: '1px solid #efebe9', marginTop: '1rem', paddingTop: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontSize: '1.1rem', fontWeight: 'bold', color: '#3e2723' }}>Tổng thanh toán:</span>
              <span style={{ fontSize: '1.5rem', fontWeight: 900, color: '#d84315' }}>
                {getCartTotal().toLocaleString('vi-VN')} VND
              </span>
            </div>

            <button type="submit" style={{ 
              width: '100%', padding: '0.85rem', backgroundColor: '#d84315', color: '#ffffff', 
              border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer',
              marginTop: '0.5rem', fontSize: '1rem', boxShadow: '0 4px 12px rgba(216, 67, 21, 0.2)'
            }}>
              🚀 Xác nhận Đặt hàng
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};

const qtyBtnStyle = {
  width: '28px',
  height: '28px',
  borderRadius: '50%',
  border: '1px solid #d7ccc8',
  backgroundColor: '#ffffff',
  fontWeight: 'bold',
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center'
};

const labelStyle = {
  display: 'block',
  marginBottom: '0.4rem',
  fontSize: '0.85rem',
  fontWeight: 600,
  color: '#5d4037'
};

const inputStyle = {
  width: '100%',
  padding: '0.6rem 0.8rem',
  border: '1px solid #d7ccc8',
  borderRadius: '8px',
  fontSize: '0.9rem',
  outline: 'none',
  boxSizing: 'border-box'
};

export default Cart;
