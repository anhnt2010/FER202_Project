import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider } from './context/CartContext';

// Layouts
import CustomerLayout from './layouts/CustomerLayout';
import AdminLayout from './layouts/AdminLayout';

// Customer Pages
import Home from './pages/customer/Home';
import ProductList from './pages/customer/ProductList';
import ProductDetail from './pages/customer/ProductDetail';
import CustomCakeDesigner from './pages/customer/CustomCakeDesigner';
import Cart from './pages/customer/Cart';
import OrderHistory from './pages/customer/OrderHistory';

// Admin Pages
import Dashboard from './pages/admin/Dashboard';
import TemplateManagement from './pages/admin/TemplateManagement';
import UserManagement from './pages/admin/UserManagement';

// Auth Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

// Route Guard to verify auth and role
const RoleProtectedRoute = ({ children, allowedRoles }) => {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/auth/login" replace />;
  }
  
  if (allowedRoles && !allowedRoles.includes(user.Role_ID)) {
    if (user.Role_ID === 'R01') return <Navigate to="/admin" replace />;
    return <Navigate to="/" replace />;
  }
  
  return children;
};

// Route Guard for customer-only pages (Admin is not allowed)
const CustomerOnlyRoute = ({ children }) => {
  const { user } = useAuth();
  if (user?.Role_ID === 'R01') {
    return <Navigate to="/admin" replace />;
  }
  return children;
};

export const App = () => {
  return (
    <AuthProvider>
      <CartProvider>
        <BrowserRouter>
          <Routes>
            {/* Auth Routes */}
            <Route path="/auth/login" element={<Login />} />
            <Route path="/auth/register" element={<Register />} />

            {/* Customer Routes (Default Shop) */}
            <Route path="/" element={<CustomerLayout />}>
              <Route index element={<Home />} />
              <Route path="products" element={<ProductList />} />
              <Route path="products/:id" element={<ProductDetail />} />
              <Route path="custom-cake" element={
                <CustomerOnlyRoute>
                  <CustomCakeDesigner />
                </CustomerOnlyRoute>
              } />
              <Route path="cart" element={<Cart />} />
              <Route path="orders" element={
                <RoleProtectedRoute allowedRoles={['R02']}>
                  <OrderHistory />
                </RoleProtectedRoute>
              } />
            </Route>

            {/* Admin Routes */}
            <Route path="/admin" element={
              <RoleProtectedRoute allowedRoles={['R01']}>
                <AdminLayout />
              </RoleProtectedRoute>
            }>
              <Route index element={<Dashboard />} />
              <Route path="orders" element={<Dashboard />} />
              <Route path="templates" element={<TemplateManagement />} />
              <Route path="users" element={<UserManagement />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </CartProvider>
    </AuthProvider>
  );
};

export default App;
