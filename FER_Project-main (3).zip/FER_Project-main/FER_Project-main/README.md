# Cửa Hàng Bánh Kem BakeryZone (ReactJS + JSON Mock Database) - Môn FER202

Hệ thống website bán và thiết kế bánh kem sinh nhật trực tuyến, xây dựng bằng **ReactJS (Vite)**, quản lý State bằng **React Context** và lưu trữ dữ liệu động bằng **LocalStorage / JSON Mock DB**.

---

## 🔑 Tài khoản đăng nhập thử nghiệm (Mật khẩu: 123)

Hệ thống được tinh gọn thành 2 vai trò chính:

1. **🛡️ Quản trị viên (Admin - Role R01)**
   - **Email:** `admin@bakeryzone.com`
   - **Chức năng:** Xem thống kê doanh thu, quản lý & cập nhật trạng thái đơn đặt bánh, thêm mới hoặc xóa mẫu bánh kem, quản lý tài khoản người dùng.

2. **🛍️ Khách hàng (Customer - Role R02)**
   - **Email:** `khachhang1@gmail.com`
   - **Chức năng:** Xem danh mục & tìm kiếm bánh, xem chi tiết & đánh giá sản phẩm, tự thiết kế bánh (chọn vị cốt bánh, số tầng, loại kem, ghi chữ chúc mừng), thêm phụ kiện sinh nhật (nến, mũ, đĩa), đặt hàng và theo dõi lịch sử đơn hàng.

---

## 📂 Cấu trúc thư mục tinh gọn

```
src/
├── assets/              # Tài nguyên tĩnh và CSS
│   └── css/             # CSS giao diện
├── context/             # Quản lý State toàn cục
│   ├── AuthContext.jsx  # Quản lý đăng nhập, phiên người dùng
│   └── CartContext.jsx  # Quản lý giỏ hàng đặt bánh
├── data/                # Mock Database lưu dạng JSON
│   ├── users.json       # Danh sách người dùng
│   ├── customers.json   # Thông tin khách hàng
│   ├── product_categories.json # Danh mục bánh
│   ├── cake_templates.json     # Mẫu bánh kem & giá niêm yết
│   ├── accessories.json        # Phụ kiện tiệc sinh nhật
│   ├── orders.json             # Danh sách đơn hàng
│   └── reviews.json            # Đánh giá nhận xét của khách
├── layouts/             # Khung Layout
│   ├── CustomerLayout.jsx  # Giao diện dành cho khách mua hàng
│   └── AdminLayout.jsx     # Giao diện trang quản trị viên
├── pages/               # Giao diện màn hình nghiệp vụ
│   ├── auth/            # Đăng nhập & Đăng ký
│   ├── customer/        # Trang chủ, Danh sách bánh, Chi tiết bánh, Tự thiết kế bánh, Giỏ hàng, Lịch sử đơn
│   └── admin/           # Dashboard (Thống kê & Đơn hàng), Quản lý mẫu bánh, Quản lý tài khoản
├── services/            # Tầng xử lý dữ liệu và CRUD LocalStorage
│   ├── db.js            # Khởi tạo LocalStorage từ JSON
│   ├── authService.js   # Xử lý đăng nhập / đăng ký
│   ├── cakeService.js   # Xử lý sản phẩm & tính giá custom cake
│   ├── orderService.js  # Xử lý đơn hàng
│   └── reviewService.js # Xử lý đánh giá
├── App.jsx              # Cấu hình định tuyến Route
└── main.jsx             # Điểm khởi chạy React
```

---

## 🚀 Hướng dẫn chạy đồ án (Local Run)

1. Mở terminal tại thư mục này và cài đặt thư viện:
   ```bash
   npm install
   ```
2. Chạy ứng dụng ở chế độ phát triển:
   ```bash
   npm run dev
   ```
3. Truy cập đường dẫn: **`http://localhost:3000`**
